﻿
namespace GerenciadorTarefas.Models {
    public enum AndamentoTarefa : int {
        Concluido,
        Em_Andamento
    }
}
